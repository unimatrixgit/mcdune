# Dune Resource Pack

Client-side resource pack for Minecraft Java 1.21.4 / Paper 1.21.4.

- Gives Sniffers a sandworm-inspired texture.
- Gives Husk zombies a haunted Fremen stillsuit texture.
- Recolors suspicious sand to a bright spice-gold so deposits are easier to spot.

Install `DuneResourcePack.zip` in `.minecraft/resourcepacks` and enable it in Options → Resource Packs. For a server-wide pack, host the ZIP at a direct-download URL and set `resource-pack` in `server.properties` for each backend. Players must accept it. This pack changes textures only; Sniffers keep their vanilla model geometry.
